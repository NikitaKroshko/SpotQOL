# SpotQOL

My University has a platform for showing student grades which is called Spot. I sometimes work in dark environments and prefer not to be blinded by a white screen in the middle of the night. As such I created a Manifest V2 extension which allows the user to change the colouring of the page to their desired preference.
